Este repositorio contiene el código correspondiente al desarrollo de la app móvil Club Deportivo del grupo 4 B
Salcedo, Espindola, Pasini, Brondo, Morgante.
